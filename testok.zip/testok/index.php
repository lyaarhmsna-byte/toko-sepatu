<?php
session_start();

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if (isset($_POST['add'])) {
    $_SESSION['cart'][] = [
        'name' => $_POST['name'],
        'price' => $_POST['price']
    ];
}

if (isset($_POST['checkout'])) {
    $_SESSION['show_nota'] = true;
}

if (isset($_POST['back'])) {
    $_SESSION['show_nota'] = false;
    $_SESSION['cart'] = [];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Toko Sepatu PHP</title>

<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:Arial}
body{background:#f2f2f2}
header{
  background:#111;color:#fff;
  padding:15px 30px;
  display:flex;justify-content:space-between
}
.container{padding:30px}
.products{
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
  gap:20px
}
.card{
  background:#fff;border-radius:10px;
  box-shadow:0 5px 10px rgba(0,0,0,.15);
  overflow:hidden
}
.card img{width:100%;height:180px;object-fit:cover}
.card-body{padding:15px}
.card-body p{color:green;font-weight:bold}
button{
  width:100%;padding:10px;
  background:#0d6efd;color:#fff;
  border:none;border-radius:5px;cursor:pointer
}
.cart,.nota{
  margin-top:30px;background:#fff;
  padding:20px;border-radius:10px
}
.nota{
  border:2px dashed #333;
  max-width:400px;margin:30px auto
}
.total{font-weight:bold;margin-top:10px}
</style>
</head>

<body>

<header>
  <h2>Toko Sepatu PHP</h2>
  <div>Keranjang: <?= count($_SESSION['cart']) ?></div>
</header>

<div class="container">

<?php if (isset($_SESSION['show_nota']) && $_SESSION['show_nota'] === true): ?>

<!-- ================= STRUK / NOTA ================= -->
<div class="nota">
  <h3 style="text-align:center">NOTA PESANAN</h3>
  <p>Tanggal: <?= date("d-m-Y H:i") ?></p>
  <hr>

  <?php $total=0; foreach($_SESSION['cart'] as $item): ?>
    <?= $item['name'] ?> - Rp <?= number_format($item['price']) ?><br>
    <?php $total += $item['price']; ?>
  <?php endforeach; ?>

  <hr>
  <div class="total">Total Bayar: Rp <?= number_format($total) ?></div>

  <form method="POST">
    <button name="back">Kembali Belanja</button>
  </form>
</div>

<?php else: ?>

<!-- ================= TOKO ================= -->
<div class="products">

<form method="POST" class="card">
  <img src="nb.jpeg">
  <div class="card-body">
    <h4>Sepatu Sport</h4>
    <p>Rp 350.000</p>
    <input type="hidden" name="name" value="Sepatu Sport">
    <input type="hidden" name="price" value="350000">
    <button name="add">Tambah</button>
  </div>
</form>

<form method="POST" class="card">
  <img src="lari.jpeg">
  <div class="card-body">
    <h4>Sneakers Casual</h4>
    <p>Rp 420.000</p>
    <input type="hidden" name="name" value="Sneakers Casual">
    <input type="hidden" name="price" value="420000">
    <button name="add">Tambah</button>
  </div>
</form>

<form method="POST" class="card">
  <img src="puma.jpeg">
  <div class="card-body">
    <h4>Sepatu Lari</h4>
    <p>Rp 390.000</p>
    <input type="hidden" name="name" value="Sepatu Lari">
    <input type="hidden" name="price" value="390000">
    <button name="add">Tambah</button>
  </div>
</form>

</div>

<!-- ================= KERANJANG ================= -->
<div class="cart">
  <h3>Keranjang</h3>

  <?php $total=0; foreach($_SESSION['cart'] as $item): ?>
    <?= $item['name'] ?> - Rp <?= number_format($item['price']) ?><br>
    <?php $total += $item['price']; ?>
  <?php endforeach; ?>

  <div class="total">Total: Rp <?= number_format($total) ?></div>

  <?php if (!empty($_SESSION['cart'])): ?>
  <form method="POST">
    <button name="checkout" style="background:green;margin-top:10px">
      Pesan Sekarang
    </button>
  </form>
  <?php endif; ?>
</div>

<?php endif; ?>

</div>
</body>
</html>
